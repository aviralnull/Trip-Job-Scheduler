package com.moveinsync.scheduler.api;

import com.moveinsync.scheduler.api.dto.ExecutionResponse;
import com.moveinsync.scheduler.domain.JobRun;
import com.moveinsync.scheduler.repository.JobRepository;
import com.moveinsync.scheduler.repository.JobRunRepository;
import com.moveinsync.scheduler.repository.UserRepository;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/v1/executions")
public class ExecutionController {

    private final JobRunRepository runs;
    private final UserRepository users;
    private final JobRepository jobs;

    public ExecutionController(
        JobRunRepository runs,
        UserRepository users,
        JobRepository jobs
    ) {
        this.runs = runs;
        this.users = users;
        this.jobs = jobs;
    }

    private String tenant() {
        String username = SecurityContextHolder.getContext()
            .getAuthentication().getName();

        return users.findByUsernameIgnoreCase(username)
            .orElseThrow(() ->
                new IllegalStateException("Authenticated user not found")
            )
            .getTenantId();
    }

    @GetMapping
    public List<ExecutionResponse> getExecutions() {
        return runs.findTop100ByTenantIdOrderByCreatedAtDesc(tenant())
            .stream()
            .map(this::toResponse)
            .toList();
    }

    @GetMapping("/job/{jobId}")
    public List<ExecutionResponse> getJobExecutions(
        @PathVariable UUID jobId
    ) {
        String tenantId = tenant();

        // Check that this job belongs to the authenticated user's tenant.
        jobs.findByIdAndTenantId(jobId, tenantId)
            .orElseThrow(() -> new NoSuchElementException("Job not found"));

        return runs.findTop200ByJobIdAndTenantIdOrderByCreatedAtDesc(
                jobId, tenantId
            )
            .stream()
            .map(this::toResponse)
            .toList();
    }

    private ExecutionResponse toResponse(JobRun run) {
        return new ExecutionResponse(
            run.getId(),
            run.getJobId(),
            run.getStatus(),
            run.getAttempts(),
            run.getScheduledAt(),
            run.getStartedAt(),
            run.getFinishedAt(),
            run.getLastError()
        );
    }
}