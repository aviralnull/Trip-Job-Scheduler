// package com.moveinsync.scheduler.api;
// import com.moveinsync.scheduler.api.dto.*;
// import com.moveinsync.scheduler.domain.JobStatus;
// import com.moveinsync.scheduler.service.JobService;
// import jakarta.validation.Valid;
// import org.springframework.http.HttpStatus;
// import org.springframework.security.access.prepost.PreAuthorize;
// import org.springframework.web.bind.annotation.*;
// import java.util.*;
// @RestController @RequestMapping("/api/v1/jobs")
// public class JobController {
//  private final JobService service;
//  public JobController(JobService service){this.service=service;}
//  private String tenant(){return Optional.ofNullable(org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication())
//    .map(a->a.getName()).orElse("demo-tenant");}
//  @PostMapping @ResponseStatus(HttpStatus.CREATED) public JobResponse create(@Valid @RequestBody CreateJobRequest request){return service.create(tenant(),request);}
//  @GetMapping public List<JobResponse> list(){return service.list(tenant());}
//  @GetMapping("/{id}") public JobResponse get(@PathVariable UUID id){return service.get(tenant(),id);}
//  @PostMapping("/tenant/pause") @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')") public Map<String,String> pause(){service.tenantStatus(tenant(),JobStatus.PAUSED);return Map.of("status","paused");}
//  @PostMapping("/tenant/resume") @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')") public Map<String,String> resume(){service.tenantStatus(tenant(),JobStatus.ACTIVE);return Map.of("status","active");}


//  @PostMapping("/{id}/pause")
// @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
// public Map<String, String> pauseJob(@PathVariable UUID id) {
//     service.pauseJob(tenant(), id);
//     return Map.of("status", "paused", "message", "Job paused successfully");
// }

// @PostMapping("/{id}/resume")
// @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
// public Map<String, String> resumeJob(@PathVariable UUID id) {
//     service.resumeJob(tenant(), id);
//     return Map.of("status", "active", "message", "Job resumed successfully");
// }
// }


package com.moveinsync.scheduler.api;

import com.moveinsync.scheduler.api.dto.*;
import com.moveinsync.scheduler.domain.*;
import com.moveinsync.scheduler.repository.UserRepository;
import com.moveinsync.scheduler.service.JobService;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/v1/jobs")
public class JobController {

    private final JobService service;
    private final UserRepository users;

    public JobController(JobService service, UserRepository users) {
        this.service = service;
        this.users = users;
    }

    private String tenant() {
        String username = SecurityContextHolder.getContext()
            .getAuthentication().getName();

        return users.findByUsernameIgnoreCase(username)
            .orElseThrow(() ->
                new IllegalStateException("Authenticated user not found")
            )
            .getTenantId();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public JobResponse create(@Valid @RequestBody CreateJobRequest request) {
        return service.create(tenant(), request);
    }

    @GetMapping
    public List<JobResponse> list() {
        return service.list(tenant());
    }

    @GetMapping("/{id}")
    public JobResponse get(@PathVariable UUID id) {
        return service.get(tenant(), id);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    public JobResponse update(
        @PathVariable UUID id,
        @Valid @RequestBody UpdateJobRequest request
    ) {
        return service.update(tenant(), id, request);
    }

    @PostMapping("/tenant/pause")
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    public Map<String, String> pause() {
        service.tenantStatus(tenant(), JobStatus.PAUSED);
        return Map.of("status", "paused");
    }

    @PostMapping("/tenant/resume")
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    public Map<String, String> resume() {
        service.tenantStatus(tenant(), JobStatus.ACTIVE);
        return Map.of("status", "active");
    }

    @PostMapping("/{id}/pause")
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    public Map<String, String> pauseJob(@PathVariable UUID id) {
        service.pauseJob(tenant(), id);
        return Map.of("status", "paused");
    }

    @PostMapping("/{id}/resume")
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    public Map<String, String> resumeJob(@PathVariable UUID id) {
        service.resumeJob(tenant(), id);
        return Map.of("status", "active");
    }


    @DeleteMapping("/{id}")
@PreAuthorize("hasAnyRole('ADMIN', 'OPERATOR')")
public ResponseEntity<Void> deleteJob(@PathVariable UUID id) {
    service.deleteJob(id, tenant());
    return ResponseEntity.noContent().build();
}
}