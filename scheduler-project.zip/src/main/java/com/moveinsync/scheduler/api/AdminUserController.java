// package com.moveinsync.scheduler.api;
// import java.util.HashMap;
// import com.moveinsync.scheduler.domain.User;
// import com.moveinsync.scheduler.repository.UserRepository;

// // import jakarta.transaction.Transactional;

// import org.springframework.http.HttpStatus;
// import org.springframework.security.access.prepost.PreAuthorize;
// import org.springframework.web.bind.annotation.*;
// import org.springframework.web.server.ResponseStatusException;
// import java.util.List;
// import java.util.Map;
// import java.util.UUID;
// import org.springframework.http.HttpStatus;
// import org.springframework.transaction.annotation.Transactional;
// import org.springframework.web.bind.annotation.PatchMapping;
// import org.springframework.web.server.ResponseStatusException;
// import org.springframework.security.access.prepost.PreAuthorize;

// import java.util.List;
// import java.util.Map;

// @RestController
// @RequestMapping("/api/v1/admin/users")
// @PreAuthorize("hasRole('ADMIN')")
// public class AdminUserController {

//     private final UserRepository users;

//     public AdminUserController(UserRepository users) {
//         this.users = users;
//     }

//     @GetMapping
//     public List<Map<String, Object>> getUsers() {
//         return users.findAll().stream().map(user -> {
//             Map<String, Object> result = new HashMap<>();
//             result.put("id", user.getId());
//             result.put("name", user.getName());
//             result.put("email", user.getEmail());
//             result.put("username", user.getUsername());
//             result.put("role", user.getRole());
//             result.put("tenantId", user.getTenantId());
//             result.put("enabled", user.isEnabled());
//             return result;
//         }).toList();
//     }

//     @PutMapping("/{username}/role")
//     @Transactional
//     public Map<String, String> updateRole(
//             @PathVariable String username,
//             @RequestBody Map<String, String> body) {

//         String role = body.get("role");

//         if (!List.of("ADMIN", "OPERATOR", "EMPLOYEE").contains(role)) {
//             throw new ResponseStatusException(
//                 HttpStatus.BAD_REQUEST, "Invalid role"
//             );
//         }

//         User user = users.findByUsernameIgnoreCase(username)
//             .orElseThrow(() -> new ResponseStatusException(
//                 HttpStatus.NOT_FOUND, "User not found"
//             ));

//         if ("ADMIN".equals(user.getRole())
//                 && !"ADMIN".equals(role)
//                 && users.countByRoleAndEnabledTrue("ADMIN") <= 1) {
//             throw new ResponseStatusException(
//                 HttpStatus.CONFLICT, "Cannot demote last admin"
//             );
//         }

//         users.updateRoleByUsername(username, role);

//         return Map.of("message", "Role updated", "role", role);
//     }

//     @PutMapping("/{username}/status")
//     @Transactional
//     public Map<String, Object> updateStatus(
//             @PathVariable String username,
//             @RequestBody Map<String, Boolean> body) {

//         boolean enabled = Boolean.TRUE.equals(body.get("enabled"));

//         User user = users.findByUsernameIgnoreCase(username)
//             .orElseThrow(() -> new ResponseStatusException(
//                 HttpStatus.NOT_FOUND, "User not found"
//             ));

//         if (!enabled && "ADMIN".equals(user.getRole())
//                 && user.isEnabled()
//                 && users.countByRoleAndEnabledTrue("ADMIN") <= 1) {
//             throw new ResponseStatusException(
//                 HttpStatus.CONFLICT, "Cannot disable last admin"
//             );
//         }

//         user.setEnabled(enabled);

//         return Map.of("username", username, "enabled", enabled);
//     }



    
// @PatchMapping("/{id}")
// @Transactional
// @PreAuthorize("hasRole('ADMIN')")
// public Map<String, Object> updateUser(
//         @PathVariable UUID id,
//         @RequestBody UpdateUserRequest request) {

//     if (request.role() == null ||
//         !List.of("ADMIN", "OPERATOR", "EMPLOYEE").contains(request.role()) ||
//         request.enabled() == null) {
//         throw new ResponseStatusException(
//             HttpStatus.BAD_REQUEST, "Invalid role or status"
//         );
//     }

//     User user = users.findById(id)
//         .orElseThrow(() -> new ResponseStatusException(
//             HttpStatus.NOT_FOUND, "User not found"
//         ));

//     boolean removingAdmin =
//         "ADMIN".equals(user.getRole()) &&
//         (!"ADMIN".equals(request.role()) || !request.enabled()) &&
//         user.isEnabled();

//     if (removingAdmin &&
//         users.countByRoleAndEnabledTrue("ADMIN") <= 1) {
//         throw new ResponseStatusException(
//             HttpStatus.BAD_REQUEST,
//             "Cannot remove or disable the last active administrator"
//         );
//     }

//     user.setRole(request.role());
//     user.setEnabled(request.enabled());

//     users.save(user);

//     return Map.of(
//         "message", "User updated successfully",
//         "id", user.getId().toString(),
//         "role", user.getRole(),
//         "enabled", user.isEnabled()
//     );
// }

// public record UpdateUserRequest(String role, Boolean enabled) {}

// }







package com.moveinsync.scheduler.api;

import com.moveinsync.scheduler.domain.User;
import com.moveinsync.scheduler.repository.UserRepository;

import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/admin/users")
@PreAuthorize("hasRole('ADMIN')")
public class AdminUserController {

    private final UserRepository users;

    public AdminUserController(UserRepository users) {
        this.users = users;
    }

    // Identify the currently logged-in Admin.
    private User currentAdmin() {
        Authentication authentication =
                SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null ||
                !authentication.isAuthenticated()) {
            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED, "Authentication required"
            );
        }

        return users.findByUsernameIgnoreCase(authentication.getName())
                .filter(User::isEnabled)
                .filter(user -> "ADMIN".equals(user.getRole()))
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.FORBIDDEN, "Admin access denied"
                ));
    }

    // Find a user only inside the logged-in Admin's department.
    private User findTenantUser(UUID id, String tenantId) {
        return users.findByIdAndTenantId(id, tenantId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "User not found"
                ));
    }

    private User findTenantUserByUsername(
            String username,
            String tenantId
    ) {
        return users.findAllByTenantIdOrderByCreatedAtDesc(tenantId)
                .stream()
                .filter(user ->
                        user.getUsername().equalsIgnoreCase(username))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "User not found"
                ));
    }

    private void validateRole(String role) {
        if (!List.of("ADMIN", "OPERATOR", "EMPLOYEE").contains(role)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "Invalid role"
            );
        }
    }

    private void validateAdminRoleChange(User user, String newRole) {

        // An Admin cannot create another Admin in the same department
        // or change their own administrator role.
        if (!"ADMIN".equals(user.getRole()) &&
                "ADMIN".equals(newRole)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Cannot promote a user to ADMIN"
            );
        }
    }

    private void protectLastAdmin(
            User user,
            boolean removingAdmin,
            String tenantId
    ) {
        if (removingAdmin &&
                "ADMIN".equals(user.getRole()) &&
                users.countByRoleAndTenantIdAndEnabledTrue(
                        "ADMIN", tenantId
                ) <= 1) {

            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Cannot remove or disable the last active administrator"
            );
        }
    }

    private Map<String, Object> toResponse(User user) {
        Map<String, Object> result = new HashMap<>();

        result.put("id", user.getId());
        result.put("name", user.getName());
        result.put("email", user.getEmail());
        result.put("username", user.getUsername());
        result.put("role", user.getRole());
        result.put("tenantId", user.getTenantId());
        result.put("parentUserId", user.getParentUserId());
        result.put("enabled", user.isEnabled());
        result.put("createdAt", user.getCreatedAt());

        return result;
    }

    // GET all users belonging to the logged-in Admin's department.
    @GetMapping
    public List<Map<String, Object>> getUsers() {

        User admin = currentAdmin();

        return users.findAllByTenantIdOrderByCreatedAtDesc(
                        admin.getTenantId()
                )
                .stream()
                .map(this::toResponse)
                .toList();
    }

    // Update role using the existing username-based API.
    @PutMapping("/{username}/role")
    @Transactional
    public Map<String, String> updateRole(
            @PathVariable String username,
            @RequestBody Map<String, String> body
    ) {

        User admin = currentAdmin();
        String tenantId = admin.getTenantId();

        String role = body.get("role");
        validateRole(role);

        User user = findTenantUserByUsername(username, tenantId);

        validateAdminRoleChange(user, role);

        if (admin.getId().equals(user.getId()) &&
                !role.equals("ADMIN")) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "You cannot change your own Admin role"
            );
        }

        protectLastAdmin(
                user,
                !"ADMIN".equals(role),
                tenantId
        );

        users.updateRoleByIdAndTenantId(
                user.getId(),
                tenantId,
                role
        );

        return Map.of(
                "message", "Role updated successfully",
                "role", role
        );
    }

    // Enable or disable a user inside the current department.
    @PutMapping("/{username}/status")
    @Transactional
    public Map<String, Object> updateStatus(
            @PathVariable String username,
            @RequestBody Map<String, Boolean> body
    ) {

        User admin = currentAdmin();
        String tenantId = admin.getTenantId();

        Boolean enabled = body.get("enabled");

        if (enabled == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Enabled status is required"
            );
        }

        User user = findTenantUserByUsername(username, tenantId);

        if (admin.getId().equals(user.getId()) && !enabled) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "You cannot disable your own account"
            );
        }

        protectLastAdmin(
                user,
                !enabled,
                tenantId
        );

        user.setEnabled(enabled);
        users.save(user);

        return Map.of(
                "username", user.getUsername(),
                "enabled", user.isEnabled()
        );
    }

    // Update role and enabled status using the existing ID-based API.
    @PatchMapping("/{id}")
    @Transactional
    public Map<String, Object> updateUser(
            @PathVariable UUID id,
            @RequestBody UpdateUserRequest request
    ) {

        User admin = currentAdmin();
        String tenantId = admin.getTenantId();

        if (request.role() == null ||
                request.enabled() == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Role and enabled status are required"
            );
        }

        validateRole(request.role());

        User user = findTenantUser(id, tenantId);

        validateAdminRoleChange(user, request.role());

        if (admin.getId().equals(user.getId()) &&
                (!"ADMIN".equals(request.role()) ||
                        !request.enabled())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "You cannot change or disable your own Admin account"
            );
        }

        boolean removingAdmin =
                "ADMIN".equals(user.getRole()) &&
                (!"ADMIN".equals(request.role()) ||
                        !request.enabled()) &&
                user.isEnabled();

        protectLastAdmin(
                user,
                removingAdmin,
                tenantId
        );

        user.setRole(request.role());
        user.setEnabled(request.enabled());

        users.save(user);

        return Map.of(
                "message", "User updated successfully",
                "id", user.getId().toString(),
                "role", user.getRole(),
                "enabled", user.isEnabled()
        );
    }

    public record UpdateUserRequest(
            String role,
            Boolean enabled
    ) {
    }
}
