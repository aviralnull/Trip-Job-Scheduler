// package com.moveinsync.scheduler.repository;

// import com.moveinsync.scheduler.domain.JobRun;
// import com.moveinsync.scheduler.domain.RunStatus;
// import org.springframework.data.jpa.repository.JpaRepository;

// import java.util.*;

// public interface JobRunRepository extends JpaRepository<JobRun, UUID> {

//     Optional<JobRun> findByIdempotencyKey(String key);

//     long countByStatus(RunStatus status);

//     List<JobRun> findTop100ByTenantIdOrderByCreatedAtDesc(String tenantId);

//     List<JobRun> findTop200ByJobIdAndTenantIdOrderByCreatedAtDesc(
//         UUID jobId,
//         String tenantId
//     );

//     long countByTenantIdAndStatus(String tenantId, RunStatus status);
// }



package com.moveinsync.scheduler.repository;

import com.moveinsync.scheduler.domain.JobRun;
import com.moveinsync.scheduler.domain.RunStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.*;

public interface JobRunRepository extends JpaRepository<JobRun, UUID> {

    Optional<JobRun> findByIdempotencyKey(String key);

    long countByStatus(RunStatus status);

    // Tenant-wide execution history (Admin use).
    List<JobRun> findTop100ByTenantIdOrderByCreatedAtDesc(
        String tenantId
    );

    // Execution history of a particular job within a tenant.
    List<JobRun> findTop200ByJobIdAndTenantIdOrderByCreatedAtDesc(
        UUID jobId,
        String tenantId
    );

    long countByTenantIdAndStatus(
        String tenantId,
        RunStatus status
    );

    // Execution history for a collection of jobs.
    List<JobRun> findTop200ByJobIdInAndTenantIdOrderByCreatedAtDesc(
        Collection<UUID> jobIds,
        String tenantId
    );

    // Count executions for a collection of jobs.
    long countByJobIdInAndTenantIdAndStatus(
        Collection<UUID> jobIds,
        String tenantId,
        RunStatus status
    );

    // Execution history for a specific job, without exposing other tenants.
    @Query("""
        SELECT r FROM JobRun r
        WHERE r.jobId = :jobId
          AND r.tenantId = :tenantId
        ORDER BY r.createdAt DESC
    """)
    List<JobRun> findJobHistory(
        @Param("jobId") UUID jobId,
        @Param("tenantId") String tenantId
    );
}
