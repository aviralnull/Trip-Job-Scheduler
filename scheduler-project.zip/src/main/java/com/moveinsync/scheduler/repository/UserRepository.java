// package com.moveinsync.scheduler.repository;

// import com.moveinsync.scheduler.domain.User;
// import org.springframework.data.jpa.repository.JpaRepository;


// import java.util.List;
// import java.util.Optional;
// import java.util.UUID;

// public interface UserRepository extends JpaRepository<User, UUID> {

//     Optional<User> findByUsernameIgnoreCase(String username);

//     boolean existsByUsernameIgnoreCase(String username);

//     boolean existsByEmailIgnoreCase(String email);

//     List<User> findAllByTenantIdOrderByCreatedAtDesc(String tenantId);

//     Optional<User> findByIdAndTenantId(UUID id, String tenantId);

//     @org.springframework.data.jpa.repository.Modifying
// @org.springframework.data.jpa.repository.Query(
//     "UPDATE User u SET u.role = :role WHERE LOWER(u.username) = LOWER(:username)"
// )
// int updateRoleByUsername(
//     @org.springframework.data.repository.query.Param("username") String username,
//     @org.springframework.data.repository.query.Param("role") String role
// );
//   long countByRoleAndEnabledTrue(String role);

// }




package com.moveinsync.scheduler.repository;

import com.moveinsync.scheduler.domain.User;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface UserRepository extends JpaRepository<User, UUID> {

    // Authentication
    Optional<User> findByUsernameIgnoreCase(String username);

    boolean existsByUsernameIgnoreCase(String username);

    boolean existsByEmailIgnoreCase(String email);

    // Tenant-level user access
    List<User> findAllByTenantIdOrderByCreatedAtDesc(String tenantId);

    Optional<User> findByIdAndTenantId(UUID id, String tenantId);

    // Hierarchy: find users reporting directly to a manager
    List<User> findAllByParentUserIdOrderByCreatedAtDesc(UUID parentUserId);

    List<User> findAllByParentUserIdAndTenantIdOrderByCreatedAtDesc(
            UUID parentUserId,
            String tenantId
    );

    Optional<User> findByIdAndParentUserIdAndTenantId(
            UUID id,
            UUID parentUserId,
            String tenantId
    );

    // Role-based tenant queries
    List<User> findAllByTenantIdAndRoleOrderByCreatedAtDesc(
            String tenantId,
            String role
    );

    List<User> findAllByParentUserIdAndRoleAndTenantId(
            UUID parentUserId,
            String role,
            String tenantId
    );

    // Update role only within the specified tenant
    @Modifying
    @Query("""
        UPDATE User u
        SET u.role = :role
        WHERE u.id = :userId
          AND u.tenantId = :tenantId
    """)
    int updateRoleByIdAndTenantId(
            @Param("userId") UUID userId,
            @Param("tenantId") String tenantId,
            @Param("role") String role
    );

    // Count enabled users within a tenant
    long countByRoleAndTenantIdAndEnabledTrue(
            String role,
            String tenantId
    );

    // Check direct manager relationship
    boolean existsByIdAndParentUserIdAndTenantId(
            UUID id,
            UUID parentUserId,
            String tenantId
    );
}
