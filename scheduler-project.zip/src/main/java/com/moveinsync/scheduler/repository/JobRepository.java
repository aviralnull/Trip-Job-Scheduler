// package com.moveinsync.scheduler.repository;

// import com.moveinsync.scheduler.domain.*;
// import org.springframework.data.jpa.repository.*;
// import org.springframework.data.repository.query.Param;

// import java.time.Instant;
// import java.util.*;

// public interface JobRepository extends JpaRepository<ScheduledJob, UUID> {

//     List<ScheduledJob>
//     findTop500ByStatusAndNextFireAtLessThanEqualOrderByPriorityDescNextFireAtAsc(
//         JobStatus status,
//         Instant now
//     );

//     Optional<ScheduledJob> findByIdAndTenantId(UUID id, String tenantId);

//     List<ScheduledJob> findByTenantIdAndStatus(
//         String tenantId,
//         JobStatus status
//     );

//     List<ScheduledJob> findByTenantIdOrderByCreatedAtDesc(String tenantId);

//     @Modifying
//     @Query("""
//         update ScheduledJob j
//         set j.status = :status
//         where j.tenantId = :tenant
//         and j.status in :eligibleStatuses
//     """)
//     int updateTenantStatus(
//         @Param("tenant") String tenant,
//         @Param("status") JobStatus status,
//         @Param("eligibleStatuses") Collection<JobStatus> eligibleStatuses
//     );

    
// }





package com.moveinsync.scheduler.repository;

import com.moveinsync.scheduler.domain.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.*;

public interface JobRepository extends JpaRepository<ScheduledJob, UUID> {

    // Existing due-job lookup (legacy).
    // Scheduler will be switched to the approval-aware method below.
    List<ScheduledJob>
    findTop500ByStatusAndNextFireAtLessThanEqualOrderByPriorityDescNextFireAtAsc(
        JobStatus status,
        Instant now
    );

    // Only approved or approval-exempt jobs can be picked for execution.
    @Query("""
        SELECT j FROM ScheduledJob j
        WHERE j.status = :status
          AND j.approvalStatus IN ('APPROVED', 'NOT_REQUIRED')
          AND j.nextFireAt <= :now
        ORDER BY j.priority DESC, j.nextFireAt ASC
    """)
    List<ScheduledJob>
    findTop500ApprovedJobsDueForExecution(
        @Param("status") JobStatus status,
        @Param("now") Instant now
    );

    // Find a job within a tenant.
    Optional<ScheduledJob> findByIdAndTenantId(
        UUID id,
        String tenantId
    );

    // Find jobs created by selected users within a tenant.
    List<ScheduledJob>
    findByTenantIdAndCreatedByUserIdInOrderByCreatedAtDesc(
        String tenantId,
        Collection<UUID> creatorIds
    );

    // Find jobs created by one specific user.
    List<ScheduledJob>
    findByTenantIdAndCreatedByUserIdOrderByCreatedAtDesc(
        String tenantId,
        UUID createdByUserId
    );

    // Find a specific job belonging to one of the allowed creators.
    Optional<ScheduledJob>
    findByIdAndTenantIdAndCreatedByUserIdIn(
        UUID id,
        String tenantId,
        Collection<UUID> creatorIds
    );

    // Find jobs by tenant and execution status.
    List<ScheduledJob> findByTenantIdAndStatus(
        String tenantId,
        JobStatus status
    );

    // Find all jobs in a tenant.
    List<ScheduledJob> findByTenantIdOrderByCreatedAtDesc(
        String tenantId
    );

    // Approval queue for a tenant.
    List<ScheduledJob>
    findByTenantIdAndApprovalStatusOrderByCreatedAtDesc(
        String tenantId,
        String approvalStatus
    );

    // Find pending approvals created by selected users.
    List<ScheduledJob>
    findByTenantIdAndCreatedByUserIdInAndApprovalStatusOrderByCreatedAtDesc(
        String tenantId,
        Collection<UUID> creatorIds,
        String approvalStatus
    );

    // Existing tenant-wide status update.
    @Modifying
    @Query("""
        UPDATE ScheduledJob j
        SET j.status = :status
        WHERE j.tenantId = :tenant
          AND j.status IN :eligibleStatuses
    """)
    int updateTenantStatus(
        @Param("tenant") String tenant,
        @Param("status") JobStatus status,
        @Param("eligibleStatuses") Collection<JobStatus> eligibleStatuses
    );
}
